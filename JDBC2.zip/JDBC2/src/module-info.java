/**
 * 
 */
/**
 * 
 */
module JDBC2 {
	requires java.naming;
	requires java.sql;
}